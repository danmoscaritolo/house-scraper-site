// Plotted listing check, extension version. Same rules as the site's Check page (hs/web/app/22-check.js):
// recent sales of similar homes nearby, priced to today with the suburb's 12-month median; sales in the same
// building (units) or street (houses); the home's last sale brought forward; rents by bedrooms; the suburb's figures.
// `get(path)` returns a file's text from the Plotted site. Wording rule: "homes like this sold for", never "worth".
var PlottedCore = (function () {
  var EP = Date.UTC(2000, 0, 1);
  var cache = {};

  function parseJs(t) { var i = t.indexOf('={'); if (i < 0) i = t.indexOf('=') ; return JSON.parse(t.slice(i + 1).trim().replace(/;\s*$/, '')); }
  function load(get, path) {
    if (!cache[path]) cache[path] = get(path).then(parseJs).catch(function (e) { delete cache[path]; throw e; });
    return cache[path];
  }
  var slug = function (l) { return String(l).toUpperCase().replace(/[^A-Z0-9]/g, '_'); };
  var ABBR = { avenue: 'ave', street: 'st', road: 'rd', drive: 'dr', place: 'pl', crescent: 'cres', close: 'cl', court: 'ct', parade: 'pde', highway: 'hwy', terrace: 'tce', circuit: 'cct', boulevard: 'bvd', boulevarde: 'bvd', grove: 'gr', square: 'sq', esplanade: 'esp', lane: 'la', parkway: 'pwy', way: 'way', mount: 'mt', saint: 'st' };
  var norm = function (x) { return String(x).toLowerCase().replace(/[^a-z0-9 ]/g, ' ').split(/\s+/).filter(Boolean).map(function (w) { return ABBR[w] || w; }).join(' '); };
  var uN = function (u) { return String(u || '').toUpperCase().replace(/\s+/g, ''); };
  var nK = uN;
  function q(a, p) { if (!a.length) return null; var s = a.slice().sort(function (x, y) { return x - y; }), i = (s.length - 1) * p, lo = Math.floor(i); return s[lo] + (s[Math.min(lo + 1, s.length - 1)] - s[lo]) * (i - lo); }
  function dist(ax, ay, bx, by) { return ax == null || bx == null ? null : Math.hypot((ax - bx) * 0.92, ay - by); }
  function lastSale(p) { var s = p[7].filter(function (x) { return !x[3]; }); return s.length ? s[s.length - 1] : null; }

  function price(t, rent) {
    if (t == null) return null;
    var s = String(t).toLowerCase().replace(/,/g, ''), re = /\$\s?(\d+(?:\.\d+)?)\s*(k|m|mil|million)?\b/g, m, v = [];
    while ((m = re.exec(s))) v.push(+m[1] * (m[2] === 'k' ? 1e3 : m[2] ? 1e6 : 1));
    v = v.filter(function (x) { return rent ? x >= 50 && x <= 20000 : x >= 50000; });
    if (!v.length) return null;
    var lo = v[0], hi = v.length > 1 && v[1] > lo ? v[1] : lo;
    return { v: (lo + hi) / 2, lo: lo, hi: hi };
  }

  // Index: every 3rd month of the suburb's 12-month median; fall back to the region's.
  function mover(meta, sub, unit) {
    var ad = meta.ad, idx = sub && sub.i, reg = meta.mkt[(sub && sub.rg) || 'all'] || meta.mkt.all || {}, rs = reg[unit ? 'unit' : 'house'] || [];
    function at(j) {
      for (var k = 0; k <= 2; k++) for (var sgn = -1; sgn <= 1; sgn += 2) {
        var jj = j + k * sgn; if (jj < 0 || jj >= ad.length) continue;
        if (idx) { var o = jj - idx[0]; if (o >= 0 && o < idx[1].length && idx[1][o] != null) return [idx[1][o], 'suburb']; }
      }
      return rs[j] != null ? [rs[j], 'region'] : null;
    }
    var nowJ = ad.length - 1, now = at(nowJ);
    return function (p, day) {
      var j = 0; while (j < ad.length && ad[j] < day) j++; if (j >= ad.length) j = nowJ;
      var a = at(j); if (!a || !now) return null;
      var b = a[1] === 'suburb' ? now : (rs[nowJ] != null ? [rs[nowJ], 'region'] : null); if (!b) return null;
      var x = b[0] / a[0]; if (x < 0.4 || x > 6) return null;
      return { v: p * x, ch: x - 1, src: a[1] };
    };
  }

  async function check(get, L) {
    var res = { L: L };
    res.mode = L.mode === 'rent' || /per\s*week|\bp\.?w\b|\/\s*w(ee)?k/i.test(L.price || '') ? 'rent' : 'sale';
    res.price = price(L.price, res.mode === 'rent');
    var name = String(L.suburb || '').toUpperCase().trim();
    if (!name) { res.err = 'suburb'; return res; }
    var meta = await load(get, 'data/web/ck_meta.js');
    var letter = /[A-Z]/.test(name[0]) ? name[0] : '_';
    var subs = await load(get, 'data/web/ck_' + letter + '.js');
    var loc = null;
    [name + ' ' + L.pc, name].forEach(function (n) {
      if (loc) return;
      var h = subs[n + '|house'] || subs[n + '|unit'];
      if (h && (n !== name || !L.pc || String(h.pc) === String(L.pc) || !subs[name + ' ' + L.pc + '|house'])) loc = n;
    });
    if (!loc) { res.err = 'suburb'; return res; }
    res.loc = loc;
    var R = await load(get, 'data/props/' + slug(loc) + '.js');
    var nk = L.street ? norm(L.street) : '', sis = {};
    R.st.forEach(function (x, i) { if (nk && norm(x) === nk) sis[i] = 1; });
    var num = nK(L.num), first = num.split('-')[0], base = (first.match(/^\d+/) || [''])[0], un = uN(L.unit);
    var onSt = R.p.filter(function (p) { return sis[p[0]]; });
    var atNum = onSt.filter(function (p) { return nK(p[1]) === num; });
    if (!atNum.length && first !== num) atNum = onSt.filter(function (p) { return nK(p[1]) === first; });
    var cplx = base ? onSt.filter(function (p) { return (nK(p[1]).match(/^\d+/) || [''])[0] === base; }) : [];
    var me = atNum.filter(function (p) { return uN(p[2]) === un; })[0] || (!un && atNum.length === 1 ? atNum[0] : null);
    var lx = L.lon != null ? Math.round((+L.lon - 150) * 1e5) : null, ly = L.lat != null ? Math.round((+L.lat + 34) * 1e5) : null;
    if (!me && lx != null && !un) {
      var bd = 1e9; R.p.forEach(function (p) { if (p[5]) return; var d = dist(p[3], p[4], lx, ly); if (d != null && d < bd) { bd = d; me = p; } });
      if (bd > 25) me = null;
    }
    if (me && me[3] != null) { lx = me[3]; ly = me[4]; }
    if (lx == null) { var pts = (atNum.length ? atNum : onSt).filter(function (p) { return p[3] != null; }); if (pts.length) { lx = pts[pts.length >> 1][3]; ly = pts[pts.length >> 1][4]; } }
    var unit = me ? me[5] === 1 : (!!L.unit || /apartment|unit|flat|studio/i.test(L.type || ''));
    res.unit = unit; res.seg = unit ? 'unit' : 'house';
    var sub = subs[loc + '|' + res.seg] || null;
    res.pc = String(L.pc || (sub && sub.pc) || '');
    var move = mover(meta, sub, unit), now = Math.round((Date.parse(meta.asof + 'T00:00:00Z') - EP) / 864e5);
    var adj = function (p, d) { var e = move(p, d); return e ? e.v : p; };
    var bld = (cplx.length ? cplx : atNum).filter(function (p) { return p[5] === 1; });
    res.multi = Object.keys(bld.reduce(function (o, p) { o[nK(p[1])] = 1; return o; }, {})).length > 1;

    // same building (units, 10 years) or street (houses, 5 years), newest first
    var nearPs = unit ? bld : onSt, yrs = unit ? 10 : 5, near = [];
    nearPs.forEach(function (p) {
      if (p === me || p[5] !== (unit ? 1 : 0) || (p[8] && p[8][0] === 'p')) return;
      p[7].forEach(function (s) { if (!s[3] && s[0] >= now - yrs * 365.25) near.push({ p: p, s: s, adj: adj(s[2], s[0]) }); });
    });
    near.sort(function (a, b) { return b.s[0] - a.s[0]; });

    // the wider comparison
    var land = L.land || (me && me[6]) || null;
    var basePs = R.p.filter(function (p) { return p !== me && p[5] === (unit ? 1 : 0) && !(p[8] && p[8][0] === 'p'); });
    var steps = unit ? [[12, 0], [24, 0]] : land ? [[12, .25], [12, .4], [24, .4], [24, 0]] : [[12, 0], [24, 0]], pick = [], used = steps[0];
    for (var i = 0; i < steps.length; i++) {
      used = steps[i]; pick = [];
      basePs.forEach(function (p) {
        var s = lastSale(p); if (!s || s[0] < now - used[0] * 30.44) return;
        if (used[1] && !(p[6] > 0 && Math.abs(p[6] / land - 1) <= used[1])) return;
        pick.push({ p: p, s: s, adj: adj(s[2], s[0]), d: dist(p[3], p[4], lx, ly) });
      });
      if (pick.length >= 8) break;
    }
    pick.sort(function (a, b) { return (a.d == null ? 1e9 : a.d) - (b.d == null ? 1e9 : b.d) || b.s[0] - a.s[0]; });
    pick = pick.slice(0, 25);
    var bld3 = [], seen = [];
    near.forEach(function (c) { if (unit && c.s[0] >= now - 3 * 365.25 && seen.indexOf(c.p) < 0) { seen.push(c.p); bld3.push(c); } });
    res.useBld = unit && bld3.length >= 4;
    var basis = res.useBld ? bld3 : pick, vals = basis.map(function (c) { return c.adj; }).filter(function (x) { return x > 0; });
    res.st = vals.length ? { n: vals.length, q25: q(vals, .25), med: q(vals, .5), q75: q(vals, .75) } : null;
    res.dist = vals.map(function (v) { return Math.round(v); });   // every comparable, for the card's distribution plot
    res.months = used[0]; res.tol = used[1]; res.land = land;
    if (res.mode === 'sale' && res.price && res.st && res.st.n >= 3) {
      var v = res.price.v; res.ver = { k: v < res.st.q25 ? 'below' : v > res.st.q75 ? 'above' : 'inline', diff: v / res.st.med - 1 };
    }
    if (me) { var ls = lastSale(me); if (ls) { res.last = { price: ls[2], day: ls[0], n: me[7].length, est: move(ls[2], ls[0]) }; } }
    // rents
    try {
      var RB = await load(get, 'data/web/rentb.js');
      var beds = L.beds != null && L.beds !== '' ? Math.min(5, +L.beds) : null, rk = res.pc + '|' + res.seg + '|';
      res.rent = (beds != null && RB.r[rk + beds] && { beds: beds, v: RB.r[rk + beds] }) || (RB.r[rk + '*'] && { beds: null, v: RB.r[rk + '*'] }) || null;
      res.rentAsof = RB.asof;
      if (res.mode === 'rent' && res.rent && res.price) { var rv = res.rent.v, pv = res.price.v; res.ver = { k: pv < rv[1] ? 'below' : pv > rv[3] ? 'above' : 'inline', diff: pv / rv[2] - 1, rent: true }; }
    } catch (e) {}
    res.sub = sub && { med: sub.r[0], n: sub.r[1], g1: sub.r[2], fp: sub.r[3], rent: sub.r[4] };
    res.asof = meta.asof;
    var addr = function (p) { return (p[2] ? String(p[2]).replace(/\s+/g, '') + '/' : '') + (p[1] ? p[1] + ' ' : '') + R.st[p[0]]; };
    res.near = near.slice(0, 80).map(function (c) { return { a: addr(c.p), day: c.s[0], price: c.s[2], adj: c.adj, land: c.p[6] }; });
    // the suburb: single sales of the same type in the last 12 months, newest first
    var subS = [];
    R.p.forEach(function (p) { if (p[5] !== (unit ? 1 : 0)) return; p[7].forEach(function (s) { if (!s[3] && s[0] >= now - 365.25) subS.push({ a: addr(p), day: s[0], price: s[2], land: p[6] }); }); });
    subS.sort(function (a, b) { return b.day - a.day; });
    res.subSales = subS.slice(0, 120); res.nSub = subS.length;
    res.nNear = near.length;
    res.found = !!me;
    return res;
  }

  return { check: check, price: price, _clear: function () { cache = {}; } };
})();
if (typeof module !== 'undefined') module.exports = PlottedCore;
