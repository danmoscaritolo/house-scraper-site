// On Plotted itself: copy the budget limits the user set in "Your budget" into the extension's storage on this
// device, so listing cards can say whether a price fits. Only two numbers are kept (buy and rent limits); they never
// leave this browser.
(function () {
  function copy() {
    try {
      var c = JSON.parse(localStorage.getItem('hs_cap') || 'null');
      if (c) chrome.storage.local.set({ cap: { buy: c.buy || null, rent: c.rent || null, t: c.t || Date.now() } });
    } catch (e) {}
  }
  copy();
  window.addEventListener('message', function (e) {
    if (e.source === window && e.data && e.data.plottedCap) setTimeout(copy, 50);
  });
  setInterval(copy, 5000);
})();
