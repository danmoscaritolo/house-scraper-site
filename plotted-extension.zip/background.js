// Plotted extension background: fetches Plotted's public data files and runs the listing check.
// Only Plotted's own site is contacted. Nothing about the user or the listing is sent: the files are the same for everyone.
importScripts('core.js');

var PLOTTED = 'https://danmoscaritolo.github.io/house-scraper-site/';

function get(path) {
  return fetch(PLOTTED + path, { cache: 'default' }).then(function (r) {
    if (!r.ok) throw new Error(path + ' ' + r.status);
    return r.text();
  });
}

chrome.runtime.onMessage.addListener(function (msg, sender, reply) {
  if (!msg || msg.type !== 'check') return;
  PlottedCore.check(get, msg.L).then(function (res) { reply({ ok: true, res: res }); },
    function (e) { reply({ ok: false, err: String(e && e.message || e) }); });
  return true;   // reply comes later
});

// Fresh data each week: forget cached files once a day.
setInterval(function () { PlottedCore._clear(); }, 24 * 3600 * 1000);
