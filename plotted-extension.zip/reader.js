// Plotted extension: reads the listing's facts from the page the user has open (runs in the page so it can see
// the page's own data), and hands them to card.js. Nothing is stored or sent from here.
(function () {
  if (window.__plottedReader) return;
  window.__plottedReader = true;

  var STATES = 'NSW|VIC|QLD|SA|WA|TAS|ACT|NT';

  function listingId() {
    var h = location.hostname, p = location.pathname;
    var m;
    if (/domain\./.test(h) && (m = p.match(/^\/([a-z0-9-]+)-(\d{7,})\/?$/))) return { site: 'domain', id: m[2], slug: m[1] };
    if (/realestate\./.test(h)) {
      if ((m = p.match(/\/property-([a-z+]+)-([a-z]{2,3})-(.+)-(\d{6,})\/?$/i)))
        return { site: 'rea', id: m[4], type: m[1].replace(/\+/g, ' '), state: m[2], suburb: decodeURIComponent(m[3]).replace(/[+-]/g, ' ') };
      // Looser: any REA page whose address ends in a long listing number.
      if ((m = p.match(/-(\d{7,})\/?$/))) return { site: 'rea', id: m[1] };
    }
    return null;
  }

  function n(x) {
    if (x == null) return null;
    if (typeof x === 'object') x = x.value != null ? x.value : x.displayValue;
    var m = String(x).replace(/,/g, '').match(/\d+(\.\d+)?/);
    return m ? +m[0] : null;
  }

  function read(L) {
    var d = document, r = { src: L.site, id: L.id }, how = {};
    function set(k, v, src) { if (v == null || v === '' || r[k] != null) return; r[k] = v; how[k] = src; }

    // Domain: Next.js data block. Only trust it if it belongs to this listing
    // (after in-site navigation the block can still describe the first page).
    try {
      var nd = d.getElementById('__NEXT_DATA__');
      if (nd) {
        var ndj = JSON.parse(nd.textContent);
        var c = ndj.props.pageProps.componentProps || {};
        if (String(c.listingId || c.id) === L.id) {
          var s = c.listingSummary || {};
          set('addr', c.address || s.address, 'data');
          set('unit', c.unitNumber, 'data');
          set('num', c.streetNumber, 'data');
          set('street', c.street, 'data');
          set('suburb', c.suburb, 'data');
          set('pc', c.postcode, 'data');
          set('state', c.stateAbbreviation, 'data');
          set('type', s.propertyType || c.propertyType, 'data');
          set('beds', n(s.beds != null ? s.beds : c.beds), 'data');
          set('baths', n(s.baths), 'data');
          set('cars', n(s.parking), 'data');
          (s.stats || []).forEach(function (t) {
            if (t.key === 'landArea') set('land', n(t.value), 'data');
            if (t.key === 'buildingArea') set('floor', n(t.value), 'data');
          });
          set('price', s.title, 'data');
          set('mode', s.mode === 'buy' ? 'sale' : s.mode, 'data');
        }
        // Opened from search results: the data block still describes the search page,
        // but it keeps a summary of each listing it showed.
        var lmod = c.listingsMap && c.listingsMap[L.id] && c.listingsMap[L.id].listingModel;
        if (lmod) {
          var la = lmod.address || {}, lf = lmod.features || {};
          set('street', la.street, 'data');
          set('suburb', la.suburb, 'data');
          set('pc', la.postcode, 'data');
          set('state', la.state, 'data');
          if (la.street) set('addr', la.street + ', ' + la.suburb + ' ' + la.state + ' ' + la.postcode, 'data');
          set('lat', la.lat, 'data');
          set('lon', la.lng, 'data');
          set('type', lf.propertyTypeFormatted || lf.propertyType, 'data');
          set('beds', n(lf.beds), 'data');
          set('baths', n(lf.baths), 'data');
          set('cars', n(lf.parking), 'data');
          if (lf.landSize) set('land', sz({ value: lf.landSize, unit: lf.landUnit }), 'data');
          set('price', lmod.price, 'data');
          var lt = (ndj.query && ndj.query.listingType) || '';
          if (/^(sale|rent|sold)$/.test(lt)) set('mode', lt, 'data');
        }
      }
    } catch (e) {}

    // REA: the page holds several listings (this one plus "similar properties"),
    // so only use the record whose id is this listing's id.
    function sz(p) {
      if (!p) return null;
      var v = n(p.displayValue != null ? p.displayValue : p.value);
      var u = ((p.sizeUnit && p.sizeUnit.displayValue) || p.unit || '').toLowerCase();
      if (v == null) return null;
      if (/ha|hectare/.test(u)) v *= 10000; else if (/acre/.test(u)) v *= 4046.86;
      return Math.round(v);
    }
    function findRecord(root, id) {
      var seen = 0, found = null;
      (function walk(o, depth) {
        if (found || seen > 60000 || depth > 20 || o == null) return;
        seen++;
        if (typeof o === 'string') {
          if (o.length > 40 && (o[0] === '{' || o[0] === '[')) { try { walk(JSON.parse(o), depth + 1); } catch (e) {} }
          return;
        }
        if (typeof o !== 'object') return;
        if (String(o.id) === id && (o.generalFeatures || o.address || o.price)) { found = o; return; }
        for (var k in o) { if (Object.prototype.hasOwnProperty.call(o, k)) walk(o[k], depth + 1); }
      })(root, 0);
      return found;
    }
    if (L.site === 'rea') {
      var rec = null;
      try { if (window.ArgonautExchange) rec = findRecord(window.ArgonautExchange, L.id); } catch (e) {}
      if (rec) {
        var g = rec.generalFeatures || {};
        set('beds', n(g.bedrooms), 'data');
        set('baths', n(g.bathrooms), 'data');
        set('cars', n(g.parkingSpaces), 'data');
        var ps = rec.propertySizes || {};
        set('land', sz(ps.land), 'data');
        set('floor', sz(ps.building), 'data');
        var ad = rec.address || {}, disp = ad.display || {};
        set('addr', disp.fullAddress, 'data');
        set('street', disp.shortAddress, 'data');
        set('suburb', ad.suburb, 'data');
        set('pc', ad.postcode, 'data');
        set('state', ad.state, 'data');
        if (disp.geocode) { set('lat', disp.geocode.latitude, 'data'); set('lon', disp.geocode.longitude, 'data'); }
        if (rec.propertyType) set('type', rec.propertyType.display, 'data');
        if (rec.price) set('price', rec.price.display, 'data');
        var tn = rec.__typename || '';
        set('mode', /Rent/.test(tn) ? 'rent' : /Sold/.test(tn) ? 'sold' : /Buy/.test(tn) ? 'sale' : null, 'data');
      }
    }

    // Fallbacks: page title, the link itself, then visible text.
    var og = d.querySelector('meta[property="og:title"]');
    var title = (og && og.content) || d.title || '';
    var am = title.match(new RegExp('(?:for (?:sale|rent) at |^)([^|]*?\\b(?:' + STATES + ')\\b\\s*\\d{4})', 'i'));
    if (am) set('addr', am[1].trim(), 'title');
    if (L.site === 'domain' && L.slug) {
      var sm = L.slug.match(new RegExp('^(.*)-(' + STATES.toLowerCase() + ')-(\\d{4})$'));
      if (sm) { set('addr', sm[1].replace(/-/g, ' ') + ' ' + sm[2].toUpperCase() + ' ' + sm[3], 'link'); set('pc', sm[3], 'link'); }
    }
    if (L.site === 'rea' && L.suburb) { set('suburb', L.suburb, 'link'); set('type', L.type, 'link'); set('state', L.state.toUpperCase(), 'link'); }

    var main = d.querySelector('main') || d.body;
    var t = (main.innerText || '').slice(0, 20000);
    function rx(re) { var m = t.match(re); return m ? +m[1] : null; }
    set('beds', rx(/(\d+)\s*(?:bed|bedroom)s?\b/i), 'text');
    set('baths', rx(/(\d+)\s*(?:bath|bathroom)s?\b/i), 'text');
    set('cars', rx(/(\d+)\s*(?:car|parking|garage)(?:\s*space)?s?\b/i), 'text');
    var unitish = r.unit || /apartment|unit|flat|studio/i.test(r.type || '');
    var lm = t.match(/([\d,]+(?:\.\d+)?)\s*(m²|m2|sqm|ha)\b/i);
    if (lm && !unitish && r.floor == null) set('land', Math.round(n(lm[1]) * (/ha/i.test(lm[2]) ? 10000 : 1)), 'text');
    var pm = t.match(/(?:guide|offers? (?:over|above)|from)?\s*\$\s?[\d,.]+\s*(?:k|m|million)?(?:\s*[-–]\s*\$\s?[\d,.]+\s*(?:k|m|million)?)?/i);
    if (pm) set('price', pm[0].trim(), 'text');

    if (r.street && r.num == null) {
      var sa = String(r.street).match(/^(?:(?:unit|apt|apartment|shop|lot)\s*)?(?:([\w]+)\s*\/\s*)?(\d+[a-z]?(?:-\d+[a-z]?)?)\s+(.+)$/i);
      if (sa) { if (sa[1]) set('unit', sa[1], how.street); set('num', sa[2], how.street); r.street = sa[3]; }
    }
    r.url = location.origin + location.pathname;
    return { r: r, how: how };
  }

  if (window.__plottedTestHook) { window.__plottedTestHook({ read: read, listingId: listingId }); return; }

  // Watch for listing pages (both sites change page without a full reload) and post what we read.
  var curId = null, tries = 0, lastJson = '';
  function tick() {
    var L = listingId(), id = L ? L.site + L.id : null;
    if (id !== curId) { curId = id; tries = 0; lastJson = ''; if (!L) window.postMessage({ __plotted: 'none' }, location.origin); }
    if (!L || tries >= 6) return;
    tries++;
    try {
      var res = read(L), j = JSON.stringify(res.r);
      if (j !== lastJson) { lastJson = j; window.postMessage({ __plotted: 'listing', key: id, r: res.r, how: res.how }, location.origin); }
    } catch (e) { console.warn('[plotted] could not read the listing:', e); }
  }
  setInterval(tick, 1500);
  tick();
})();
