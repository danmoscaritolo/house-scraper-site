// Plotted extension card: shows the listing check on Domain and realestate.com.au listing pages.
// Gets the listing's facts from reader.js, asks the background for the check, and reads the user's budget
// limits from this device's extension storage (copied there by plotted.js when they use Plotted).
(function () {
  if (window.__plottedCard) return;
  window.__plottedCard = true;
  var PLOTTED = 'https://danmoscaritolo.github.io/house-scraper-site/';
  var cur = null, seq = 0, closedKey = null;

  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function money(v) { if (v == null) return '–'; return '$' + (v >= 1e6 ? (v / 1e6).toFixed(v >= 1e7 ? 1 : 2) + 'm' : Math.round(v / 1e3) + 'k'); }
  function pct(v) { return Math.round(Math.abs(v) * 100) + '%'; }
  function mon(day) { return new Date(Date.UTC(2000, 0, 1) + day * 864e5).toLocaleDateString('en-AU', { month: 'short', year: 'numeric', timeZone: 'UTC' }); }
  function title(s) { return String(s || '').toLowerCase().replace(/(^|[\s-])([a-z])/g, function (m, a, b) { return a + b.toUpperCase(); }); }
  function link(r) {
    var q = [];
    ['src', 'url', 'addr', 'unit', 'num', 'street', 'suburb', 'pc', 'state', 'type', 'beds', 'baths', 'cars', 'land', 'floor', 'price', 'mode', 'lat', 'lon', 'id']
      .forEach(function (k) { if (r[k] != null && r[k] !== '') q.push(k + '=' + encodeURIComponent(r[k])); });
    return PLOTTED + '#check?' + q.join('&');
  }
  function getCap() { return new Promise(function (ok) { try { chrome.storage.local.get('cap', function (o) { ok((o && o.cap) || null); }); } catch (e) { ok(null); } }); }

  function box() {
    var c = document.getElementById('plotted-card');
    if (!c) {
      c = document.createElement('div'); c.id = 'plotted-card';
      c.addEventListener('click', onClick);
      document.body.appendChild(c);
    }
    var min = false; try { min = sessionStorage.getItem('plotted-min') === '1'; } catch (e) {}
    c.classList.toggle('pc-min', min);
    return c;
  }
  function head(sum) {
    var min = document.getElementById('plotted-card') && document.getElementById('plotted-card').classList.contains('pc-min');
    return '<div class="pc-h"><span class="pc-wm"><svg viewBox="0 0 32 32" aria-hidden="true"><path d="M5 10.5 23.5 5.5 27 25 8 27.5Z" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round"/><circle cx="23.5" cy="5.5" r="4" fill="#3F51C7"/></svg>plotted</span><span class="pc-sum">' + esc(sum || '') + '</span>' +
      '<button class="pc-ic" data-a="min" title="Minimise">' + (min ? '▴' : '▾') + '</button><button class="pc-ic" data-a="x" title="Close">×</button></div>';
  }

  var WORD = { below: 'Below similar sales', inline: 'In line with similar sales', above: 'Above similar sales' };
  var RWORD = { below: 'Below similar rents', inline: 'In line with similar rents', above: 'Above similar rents' };
  var FIT = { in: 'Within your budget', stretch: 'A stretch for your budget', out: 'Over your budget' };
  var COL = { below: '#167A49', inline: '#3F51C7', above: '#C2372B' };
  var tab = 'near', ver = null;

  // Where the listing sits among similar homes: each comparable sale is a dot on a price line (stacked where they
  // crowd), the middle half is shaded, the median ticked, and this listing is the coloured line.
  function distPlot(vals, st, pv, k, fmt) {
    var W = 300, H = 92, L = 10, R = 10, base = 58, xs = vals.slice().sort(function (a, b) { return a - b; });
    var lo = Math.min(st.q25 * 0.8, xs.length ? xs[Math.floor(xs.length * 0.03)] : st.q25, pv || Infinity), hi = Math.max(st.q75 * 1.2, xs.length ? xs[Math.ceil(xs.length * 0.97) - 1] : st.q75, pv || 0);
    var X = function (v) { return L + (Math.max(lo, Math.min(hi, v)) - lo) / (hi - lo) * (W - L - R); };
    var g = '<rect x="' + X(st.q25).toFixed(1) + '" y="' + (base - 34) + '" width="' + Math.max(2, X(st.q75) - X(st.q25)).toFixed(1) + '" height="40" rx="6" fill="#3F51C7" fill-opacity=".09"/>' +
      '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + (base + 6) + '" y2="' + (base + 6) + '" stroke="#E3E1D7"/>';
    var cols = {}; xs.forEach(function (v) { var c = Math.round(X(v) / 7), n = cols[c] = (cols[c] || 0) + 1; if (n > 5) return; g += '<circle cx="' + (c * 7).toFixed(1) + '" cy="' + (base - (n - 1) * 7) + '" r="2.8" fill="#8F8D85" fill-opacity=".75"/>'; });
    g += '<line x1="' + X(st.med).toFixed(1) + '" x2="' + X(st.med).toFixed(1) + '" y1="' + (base - 36) + '" y2="' + (base + 10) + '" stroke="#141413" stroke-width="1.2" stroke-dasharray="2 2"/>' +
      '<text x="' + X(st.med).toFixed(1) + '" y="' + (base + 24) + '" text-anchor="middle">median ' + fmt(st.med) + '</text>' +
      '<text x="' + L + '" y="' + (base + 24) + '">' + fmt(lo) + '</text><text x="' + (W - R) + '" y="' + (base + 24) + '" text-anchor="end">' + fmt(hi) + '</text>';
    if (pv) { var c = COL[k] || '#3F51C7', x = X(pv); g += '<line x1="' + x.toFixed(1) + '" x2="' + x.toFixed(1) + '" y1="' + (base - 40) + '" y2="' + (base + 10) + '" stroke="' + c + '" stroke-width="2.5"/>' +
      '<rect x="' + Math.max(0, Math.min(W - 92, x - 46)).toFixed(1) + '" y="0" width="92" height="16" rx="8" fill="' + c + '"/><text class="pc-lt" x="' + Math.max(46, Math.min(W - 46, x)).toFixed(1) + '" y="11.5" text-anchor="middle">this one ' + fmt(pv) + '</text>'; }
    return '<svg class="pc-dist" viewBox="0 0 ' + W + ' ' + H + '" aria-hidden="true">' + g + '</svg>';
  }
  function verdict(k, diff, word, plot, line) {
    var big = diff == null ? '' : Math.abs(diff) < 0.005 ? 'At the median' : pct(diff) + (diff < 0 ? ' below' : ' above') + ' the median';
    return '<div class="pc-v k-' + (k || 'none') + '"><span class="pc-vk">' + esc(word) + '</span>' + (big ? '<b>' + esc(big) + '</b>' : '') + '</div>' + plot + '<p class="pc-vs">' + line + '</p>';
  }
  function list(rows, empty) {
    if (!rows.length) return '<p class="pc-note">' + esc(empty) + '</p>';
    return '<div class="pc-list">' + rows.map(function (n) { return '<div class="pc-nr"><span>' + esc(n.a) + '</span><span><b>' + money(n.price) + '</b> ' + mon(n.day) + '</span></div>'; }).join('') + '</div>';
  }

  function render(r, res, cap, err) {
    var c = box(), facts = [r.beds != null ? r.beds + ' bed' : '', r.baths != null ? r.baths + ' bath' : '', r.cars != null ? r.cars + ' car' : '',
      r.land ? Math.round(r.land) + ' m² land' : '', r.floor ? Math.round(r.floor) + ' m²' : ''].filter(Boolean);
    var html = '', sum = '';
    if (ver && ver.latest && newer(ver.latest, ver.current)) html += '<a class="pc-upd" href="' + PLOTTED + '#extension" target="_blank" rel="noopener"><b>Version ' + esc(ver.latest) + ' is available.</b> Get the update →</a>';
    if (!res && !err) html += '<div class="pc-wait"><i></i>Checking sales near this home…</div>';
    else if (err) html += '<p class="pc-note">Couldn\'t reach Plotted just now. ' + esc(err).slice(0, 80) + '</p>';
    else if (res.err) html += '<p class="pc-note">' + (r.state && !/nsw/i.test(r.state) ? 'Plotted covers NSW only.' : 'This suburb isn\'t in the NSW sales records.') + '</p>';
    else {
      var noun = res.unit ? 'units' : 'houses', sub = title(res.loc.replace(/ \d{4}$/, '')), pv = res.price && res.price.v;
      if (res.mode === 'rent') {
        if (res.rent) {
          var v = res.rent.v, who = (res.rent.beds != null ? res.rent.beds + (res.rent.beds >= 5 ? '+' : '') + '-bed ' : '') + noun + ' in postcode ' + res.pc;
          html += verdict(res.ver && res.ver.k, res.ver ? res.ver.diff : null, res.ver ? RWORD[res.ver.k] : (pv ? 'Recent rents' : 'No rent shown to compare'),
            distPlot([], { q25: v[1], med: v[2], q75: v[3] }, pv, res.ver && res.ver.k, function (x) { return '$' + Math.round(x); }),
            'Recent leases of <b>' + esc(who) + '</b>: middle half <b>$' + v[1] + '–$' + v[3] + '</b> a week, median <b>$' + v[2] + '</b> (' + v[0] + ' leases, 12 months).' +
            (res.rent.beds == null && r.beds != null ? ' <span class="pc-warn">Too few ' + r.beds + '-bed leases here, so this compares all sizes.</span>' : ''));
          sum = res.ver ? RWORD[res.ver.k] : '';
        } else html += '<p class="pc-note">No recent leases of similar homes in ' + esc(res.pc) + '.</p>';
      } else if (res.st && res.st.n >= 3) {
        var where = res.useBld ? 'units in this ' + (res.multi ? 'complex' : 'building') : (res.unit ? '' : 'similar-sized ') + noun + ' nearby';
        html += verdict(res.ver && res.ver.k, res.ver ? res.ver.diff : null, res.ver ? WORD[res.ver.k] : (pv ? 'Similar sales' : 'No price shown to compare'),
          distPlot(res.dist || [], res.st, pv, res.ver && res.ver.k, money),
          'Each dot is one of <b>' + res.st.n + ' ' + esc(where) + '</b>, priced in today\'s market. The shaded band is the middle half: <b>' + money(res.st.q25) + '–' + money(res.st.q75) + '</b>.' +
          (res.st.n < 6 ? ' <span class="pc-warn">Few sales, so treat with caution.</span>' : ''));
        sum = res.ver ? WORD[res.ver.k] : '';
      } else html += '<p class="pc-note">Too few recent sales nearby to compare.</p>';
      // budget
      if (res.mode === 'rent' ? cap && cap.rent : cap && cap.buy) {
        if (pv) {
          var lim = res.mode === 'rent' ? cap.rent : cap.buy, x = pv / lim, k = x <= 1 ? 'in' : x <= 1.1 ? 'stretch' : 'out';
          html += '<div class="pc-fit f-' + k + '"><i></i><b>' + FIT[k] + '</b><span>limit about ' + (res.mode === 'rent' ? '$' + lim + '/wk' : money(lim)) + '</span></div>';
        }
      } else html += '<a class="pc-bud" href="' + PLOTTED + '#budget" target="_blank" rel="noopener">Set your budget on Plotted to see if listings fit →</a>';
      // tiles
      var tiles = [];
      if (res.last) {
        var e = res.last.est, ago = (Date.parse(res.asof) - Date.UTC(2000, 0, 1)) / 864e5 - res.last.day;
        tiles.push('<div class="pc-t"><span>Last sold</span><b>' + money(res.last.price) + '</b><em>' + mon(res.last.day) + (e && ago > 180 ? ' · ~' + money(e.v) + ' today' : '') + '</em></div>');
      }
      if (res.sub && res.sub.med) tiles.push('<div class="pc-t"><span>' + esc(sub) + ' ' + noun + '</span><b>' + money(res.sub.med) + '</b><em class="' + (res.sub.g1 > 0 ? 'pos' : res.sub.g1 < 0 ? 'neg' : '') + '">' +
        (res.sub.g1 != null ? (res.sub.g1 >= 0 ? '+' : '−') + (Math.abs(res.sub.g1) * 100).toFixed(1) + '% on a year' : 'median') + '</em></div>');
      if (res.rent && res.mode !== 'rent') tiles.push('<div class="pc-t"><span>Rent, ' + (res.rent.beds != null ? res.rent.beds + '-bed' : 'similar') + '</span><b>$' + res.rent.v[2] + '/wk</b><em>' + (pv ? (res.rent.v[2] * 52 / pv * 100).toFixed(1) + '% gross yield' : 'median, 12 months') + '</em></div>');
      if (tiles.length) html += '<div class="pc-tiles">' + tiles.join('') + '</div>';
      // recent sales: this building / street, or the whole suburb
      var nearLab = res.unit ? (res.multi ? 'This complex' : 'This building') : 'This street', nn = (res.near || []).length, ns = res.nSub || 0;
      if (nn || ns) {
        if (tab === 'near' && !nn) tab = 'sub';
        html += '<div class="pc-sales"><div class="pc-tabs"><button data-t="near" class="' + (tab === 'near' ? 'on' : '') + '">' + nearLab + ' <i>' + res.nNear + '</i></button><button data-t="sub" class="' + (tab === 'sub' ? 'on' : '') + '">' + esc(sub) + ' <i>' + ns + '</i></button></div>' +
          (tab === 'near' ? list(res.near || [], 'No sales recorded here.') + '<p class="pc-s">' + (res.unit ? 'Last 10 years' : 'Last 5 years') + ', newest first.</p>'
            : list(res.subSales || [], 'No sales here in the last year.') + '<p class="pc-s">All ' + noun + ' sold in ' + esc(sub) + ' in the last 12 months' + (ns > 120 ? ' (newest 120 of ' + ns + ')' : '') + '.</p>') + '</div>';
      }
    }
    c.innerHTML = head(sum) + '<div class="pc-b">' + html +
      (facts.length ? '<div class="pc-facts">' + facts.map(function (f) { return '<span>' + esc(f) + '</span>'; }).join('') + '</div>' : '') +
      '<a class="pc-go" target="_blank" rel="noopener" href="' + esc(link(r)) + '">See this home on the Plotted map</a>' +
      '<p class="pc-fine">Compared with NSW Government sales and bond records. Not a valuation.</p></div>';
    c._last = [r, res, cap, err];
  }
  function newer(a, b) { var x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (var i = 0; i < 3; i++) { if ((x[i] || 0) > (y[i] || 0)) return true; if ((x[i] || 0) < (y[i] || 0)) return false; } return false; }
  try { chrome.runtime.sendMessage({ type: 'version' }, function (v) { if (chrome.runtime.lastError) return; ver = v; var c = document.getElementById('plotted-card'); if (c && c._last) render.apply(null, c._last); }); } catch (e) {}

  function onClick(e) {
    var t = e.target.closest && e.target.closest('[data-t]'), c0 = document.getElementById('plotted-card');
    if (t && c0 && c0._last) { tab = t.getAttribute('data-t'); render.apply(null, c0._last); return; }
    var a = e.target.getAttribute && e.target.getAttribute('data-a'), c = document.getElementById('plotted-card');
    if (a === 'x') { closedKey = cur && cur.key; c.remove(); return; }
    if (a === 'min' || (e.target.closest && e.target.closest('.pc-h') && !a)) {
      var m = !c.classList.contains('pc-min'); c.classList.toggle('pc-min', m);
      try { sessionStorage.setItem('plotted-min', m ? '1' : '0'); } catch (err) {}
      var b = c.querySelector('[data-a=min]'); if (b) b.textContent = m ? '▴' : '▾';
    }
  }

  function run(msg) {
    cur = msg; var my = ++seq;
    if (closedKey === msg.key) return;
    render(msg.r, null, null, null);
    Promise.all([
      new Promise(function (ok) { try { chrome.runtime.sendMessage({ type: 'check', L: msg.r }, function (x) { ok(x || { ok: false, err: chrome.runtime.lastError && chrome.runtime.lastError.message }); }); } catch (e) { ok({ ok: false, err: String(e) }); } }),
      getCap()
    ]).then(function (out) {
      if (my !== seq) return;
      var x = out[0];
      render(msg.r, x.ok ? x.res : null, out[1], x.ok ? null : (x.err || 'no reply'));
    });
  }

  window.addEventListener('message', function (e) {
    if (e.source !== window || !e.data || !e.data.__plotted) return;
    if (e.data.__plotted === 'none') { var c = document.getElementById('plotted-card'); if (c) c.remove(); cur = null; return; }
    if (e.data.__plotted === 'listing') {
      // only re-run when the facts that matter change
      var k = JSON.stringify([e.data.key, e.data.r.suburb, e.data.r.street, e.data.r.num, e.data.r.unit, e.data.r.price, e.data.r.beds, e.data.r.land, e.data.r.lat]);
      if (cur && cur._k === k) return;
      e.data._k = k; run(e.data);
    }
  });
  try { chrome.storage.onChanged.addListener(function (ch) { if (ch.cap && cur) run(cur); }); } catch (e) {}
})();
