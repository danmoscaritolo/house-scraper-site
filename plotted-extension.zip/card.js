// Plotted extension card: shows the listing check on Domain and realestate.com.au listing pages.
// Gets the listing's facts from reader.js, asks the background for the check, and reads the user's budget
// limits from this device's extension storage (copied there by plotted.js when they use Plotted).
(function () {
  if (window.__plottedCard) return;
  window.__plottedCard = true;
  var PLOTTED = 'https://danmoscaritolo.github.io/house-scraper-site/';
  var cur = null, seq = 0, closedKey = null;

  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function money(v) { if (v == null) return '–'; return '$' + (v >= 1e6 ? (v / 1e6).toFixed(v >= 1e7 ? 1 : 2) + 'm' : Math.round(v / 1e3) + 'k'); }
  function pct(v) { return Math.round(Math.abs(v) * 100) + '%'; }
  function mon(day) { return new Date(Date.UTC(2000, 0, 1) + day * 864e5).toLocaleDateString('en-AU', { month: 'short', year: 'numeric', timeZone: 'UTC' }); }
  function title(s) { return String(s || '').toLowerCase().replace(/(^|[\s-])([a-z])/g, function (m, a, b) { return a + b.toUpperCase(); }); }
  function link(r) {
    var q = [];
    ['src', 'url', 'addr', 'unit', 'num', 'street', 'suburb', 'pc', 'state', 'type', 'beds', 'baths', 'cars', 'land', 'floor', 'price', 'mode', 'lat', 'lon', 'id']
      .forEach(function (k) { if (r[k] != null && r[k] !== '') q.push(k + '=' + encodeURIComponent(r[k])); });
    return PLOTTED + '#check?' + q.join('&');
  }
  function getCap() { return new Promise(function (ok) { try { chrome.storage.local.get('cap', function (o) { ok((o && o.cap) || null); }); } catch (e) { ok(null); } }); }

  function box() {
    var c = document.getElementById('plotted-card');
    if (!c) {
      c = document.createElement('div'); c.id = 'plotted-card';
      c.addEventListener('click', onClick);
      document.body.appendChild(c);
    }
    var min = false; try { min = sessionStorage.getItem('plotted-min') === '1'; } catch (e) {}
    c.classList.toggle('pc-min', min);
    return c;
  }
  function head(sum) {
    var min = document.getElementById('plotted-card') && document.getElementById('plotted-card').classList.contains('pc-min');
    return '<div class="pc-h"><span class="pc-wm"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 4.5 12 3l1 9-9 1.5z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><circle cx="12" cy="3" r="2" fill="#FFD166"/></svg>plotted</span><span class="pc-sum">' + esc(sum || '') + '</span>' +
      '<button class="pc-ic" data-a="min" title="Minimise">' + (min ? '▴' : '▾') + '</button><button class="pc-ic" data-a="x" title="Close">×</button></div>';
  }

  var WORD = { below: 'Below similar sales', inline: 'In line with similar sales', above: 'Above similar sales' };
  var RWORD = { below: 'Below similar rents', inline: 'In line with similar rents', above: 'Above similar rents' };
  var FIT = { in: 'Within your budget', stretch: 'A stretch for your budget', out: 'Over your budget' };
  var COL = { below: '#12A150', inline: '#4F5BD5', above: '#E5484D' };

  // The dial: -40% to +40% around the median of similar homes. Green up to the cheaper quarter, blue for the middle half,
  // red past the dearer quarter; the needle is this listing.
  function dial(diff, lo, hi, k) {
    var R = 84, cx = 110, cy = 100, span = 0.4;
    function ang(x) { x = Math.max(-span, Math.min(span, x)); return Math.PI * (1 - (x + span) / (2 * span)); }
    function pt(x, r) { var a = ang(x); return [cx + r * Math.cos(a), cy - r * Math.sin(a)]; }
    function arc(a, b, col) { var p = pt(a, R), q = pt(b, R); return '<path d="M' + p[0].toFixed(1) + ' ' + p[1].toFixed(1) + ' A' + R + ' ' + R + ' 0 0 1 ' + q[0].toFixed(1) + ' ' + q[1].toFixed(1) + '" stroke="' + col + '" stroke-width="16" fill="none"/>'; }
    lo = Math.max(-span + .01, Math.min(-.005, lo)); hi = Math.min(span - .01, Math.max(.005, hi));
    var g = arc(-span, lo, '#BDEBCF') + arc(lo, hi, '#D5D9FA') + arc(hi, span, '#FBD0D1');
    g += '<line x1="' + pt(0, R - 13)[0].toFixed(1) + '" y1="' + pt(0, R - 13)[1].toFixed(1) + '" x2="' + pt(0, R + 13)[0].toFixed(1) + '" y2="' + pt(0, R + 13)[1].toFixed(1) + '" stroke="#141413" stroke-width="1.5" stroke-dasharray="2 2"/>';
    g += '<text x="' + (cx - R) + '" y="' + (cy + 18) + '" text-anchor="middle">cheaper</text><text x="' + (cx + R) + '" y="' + (cy + 18) + '" text-anchor="middle">dearer</text><text x="' + cx + '" y="' + (cy - R - 18) + '" text-anchor="middle">median</text>';
    if (diff != null) {
      var t = pt(diff, R - 22), c = COL[k] || '#4F5BD5';
      g += '<line x1="' + cx + '" y1="' + cy + '" x2="' + t[0].toFixed(1) + '" y2="' + t[1].toFixed(1) + '" stroke="' + c + '" stroke-width="4" stroke-linecap="round"/><circle cx="' + cx + '" cy="' + cy + '" r="8" fill="' + c + '"/><circle cx="' + cx + '" cy="' + cy + '" r="3" fill="#fff"/>';
      var p2 = pt(diff, R); g += '<circle cx="' + p2[0].toFixed(1) + '" cy="' + p2[1].toFixed(1) + '" r="7" fill="#fff" stroke="' + c + '" stroke-width="3"/>';
    }
    return '<svg class="pc-dial" viewBox="0 0 220 128" aria-hidden="true">' + g + '</svg>';
  }
  function gauge(k, diff, word, line, st) {
    var big = diff == null ? '–' : Math.abs(diff) < 0.005 ? 'At the median' : pct(diff) + (diff < 0 ? ' below' : ' above');
    return '<div class="pc-g k-' + (k || 'none') + '">' + dial(diff, st ? st.lo : -.1, st ? st.hi : .1, k) +
      '<div class="pc-gt"><b>' + esc(big) + '</b><span>' + esc(word) + '</span></div></div><p class="pc-vs">' + line + '</p>';
  }

  function render(r, res, cap, err) {
    var c = box(), facts = [r.beds != null ? r.beds + ' bed' : '', r.baths != null ? r.baths + ' bath' : '', r.cars != null ? r.cars + ' car' : '',
      r.land ? Math.round(r.land) + ' m² land' : '', r.floor ? Math.round(r.floor) + ' m²' : ''].filter(Boolean);
    var html = '', sum = '';
    if (!res && !err) html = '<div class="pc-wait"><i></i>Checking sales near this home…</div>';
    else if (err) html = '<p class="pc-note">Couldn\'t reach Plotted just now. ' + esc(err).slice(0, 80) + '</p>';
    else if (res.err) html = '<p class="pc-note">' + (r.state && !/nsw/i.test(r.state) ? 'Plotted covers NSW only.' : 'This suburb isn\'t in the NSW sales records.') + '</p>';
    else {
      var noun = res.unit ? 'units' : 'houses', sub = title(res.loc.replace(/ \d{4}$/, '')), pv = res.price && res.price.v;
      if (res.mode === 'rent') {
        if (res.rent) {
          var v = res.rent.v, who = (res.rent.beds != null ? res.rent.beds + (res.rent.beds >= 5 ? '+' : '') + '-bed ' : '') + noun + ' in postcode ' + res.pc;
          html += gauge(res.ver && res.ver.k, res.ver ? res.ver.diff : null, res.ver ? RWORD[res.ver.k] : (pv ? 'Recent rents' : 'No rent shown to compare'),
            'Recent leases of <b>' + esc(who) + '</b>: middle half <b>$' + v[1] + '–$' + v[3] + '</b> a week, median <b>$' + v[2] + '</b> (' + v[0] + ' leases, last 12 months).' +
            (res.rent.beds == null && r.beds != null ? ' <span class="pc-warn">Too few ' + r.beds + '-bed leases here, so this compares all sizes.</span>' : ''),
            { lo: v[1] / v[2] - 1, hi: v[3] / v[2] - 1 });
          sum = res.ver ? RWORD[res.ver.k] : '';
        } else html += '<p class="pc-note">No recent leases of similar homes in ' + esc(res.pc) + '.</p>';
      } else if (res.st && res.st.n >= 3) {
        var where = res.useBld ? 'units in this ' + (res.multi ? 'complex' : 'building') : (res.unit ? '' : 'similar-sized ') + noun + ' nearby';
        html += gauge(res.ver && res.ver.k, res.ver ? res.ver.diff : null, res.ver ? WORD[res.ver.k] : (pv ? 'Similar sales' : 'No price shown to compare'),
          '<b>' + res.st.n + ' ' + esc(where) + '</b> sold for <b>' + money(res.st.q25) + '–' + money(res.st.q75) + '</b> in today\'s market, median <b>' + money(res.st.med) + '</b>.' +
          (res.st.n < 6 ? ' <span class="pc-warn">Few sales, so treat with caution.</span>' : ''),
          { lo: res.st.q25 / res.st.med - 1, hi: res.st.q75 / res.st.med - 1 });
        sum = res.ver ? WORD[res.ver.k] : '';
      } else html += '<p class="pc-note">Too few recent sales nearby to compare.</p>';
      // budget
      if (res.mode === 'rent' ? cap && cap.rent : cap && cap.buy) {
        if (pv) {
          var lim = res.mode === 'rent' ? cap.rent : cap.buy, x = pv / lim, k = x <= 1 ? 'in' : x <= 1.1 ? 'stretch' : 'out';
          html += '<div class="pc-fit f-' + k + '"><i></i><span><b>' + FIT[k] + '</b>limit about ' + (res.mode === 'rent' ? '$' + lim + '/wk' : money(lim)) + '</span></div>';
        }
      } else html += '<a class="pc-bud" href="' + PLOTTED + '#budget" target="_blank" rel="noopener">Set your budget on Plotted to see if listings fit →</a>';
      // tiles
      var tiles = [];
      if (res.last) {
        var e = res.last.est, ago = (Date.parse(res.asof) - Date.UTC(2000, 0, 1)) / 864e5 - res.last.day;
        tiles.push('<div class="pc-t"><span>Last sold</span><b>' + money(res.last.price) + '</b><em>' + mon(res.last.day) + (e && ago > 180 ? ' · ~' + money(e.v) + ' today' : '') + '</em></div>');
      }
      if (res.sub && res.sub.med) tiles.push('<div class="pc-t"><span>' + esc(sub) + ' ' + noun + '</span><b>' + money(res.sub.med) + '</b><em class="' + (res.sub.g1 > 0 ? 'pos' : res.sub.g1 < 0 ? 'neg' : '') + '">' +
        (res.sub.g1 != null ? (res.sub.g1 >= 0 ? '+' : '−') + (Math.abs(res.sub.g1) * 100).toFixed(1) + '% on a year' : 'median') + '</em></div>');
      if (res.rent && res.mode !== 'rent') tiles.push('<div class="pc-t"><span>Rent, ' + (res.rent.beds != null ? res.rent.beds + '-bed' : 'similar') + '</span><b>$' + res.rent.v[2] + '/wk</b><em>' + (pv ? (res.rent.v[2] * 52 / pv * 100).toFixed(1) + '% gross yield' : 'median, 12 months') + '</em></div>');
      if (tiles.length) html += '<div class="pc-tiles">' + tiles.join('') + '</div>';
      // same building / street
      if (res.near && res.near.length) {
        html += '<div class="pc-near"><p class="pc-k">' + (res.unit ? (res.multi ? 'Sold in this complex' : 'Sold in this building') : 'Sold on this street') +
          ' <span>' + res.nNear + ' in ' + (res.unit ? '10' : '5') + ' yrs</span></p>' +
          res.near.slice(0, 4).map(function (n) { return '<div class="pc-nr"><span>' + esc(n.a) + '</span><span><b>' + money(n.price) + '</b> ' + mon(n.day) + '</span></div>'; }).join('') + '</div>';
      }
    }
    c.innerHTML = head(sum) + '<div class="pc-b">' + html +
      (facts.length ? '<div class="pc-facts">' + facts.map(function (f) { return '<span>' + esc(f) + '</span>'; }).join('') + '</div>' : '') +
      '<a class="pc-go" target="_blank" rel="noopener" href="' + esc(link(r)) + '">See this home on the Plotted map</a>' +
      '<p class="pc-fine">Compared with NSW Government sales and bond records. Not a valuation.</p></div>';
  }

  function onClick(e) {
    var a = e.target.getAttribute && e.target.getAttribute('data-a'), c = document.getElementById('plotted-card');
    if (a === 'x') { closedKey = cur && cur.key; c.remove(); return; }
    if (a === 'min' || (e.target.closest && e.target.closest('.pc-h') && !a)) {
      var m = !c.classList.contains('pc-min'); c.classList.toggle('pc-min', m);
      try { sessionStorage.setItem('plotted-min', m ? '1' : '0'); } catch (err) {}
      var b = c.querySelector('[data-a=min]'); if (b) b.textContent = m ? '▴' : '▾';
    }
  }

  function run(msg) {
    cur = msg; var my = ++seq;
    if (closedKey === msg.key) return;
    render(msg.r, null, null, null);
    Promise.all([
      new Promise(function (ok) { try { chrome.runtime.sendMessage({ type: 'check', L: msg.r }, function (x) { ok(x || { ok: false, err: chrome.runtime.lastError && chrome.runtime.lastError.message }); }); } catch (e) { ok({ ok: false, err: String(e) }); } }),
      getCap()
    ]).then(function (out) {
      if (my !== seq) return;
      var x = out[0];
      render(msg.r, x.ok ? x.res : null, out[1], x.ok ? null : (x.err || 'no reply'));
    });
  }

  window.addEventListener('message', function (e) {
    if (e.source !== window || !e.data || !e.data.__plotted) return;
    if (e.data.__plotted === 'none') { var c = document.getElementById('plotted-card'); if (c) c.remove(); cur = null; return; }
    if (e.data.__plotted === 'listing') {
      // only re-run when the facts that matter change
      var k = JSON.stringify([e.data.key, e.data.r.suburb, e.data.r.street, e.data.r.num, e.data.r.unit, e.data.r.price, e.data.r.beds, e.data.r.land, e.data.r.lat]);
      if (cur && cur._k === k) return;
      e.data._k = k; run(e.data);
    }
  });
  try { chrome.storage.onChanged.addListener(function (ch) { if (ch.cap && cur) run(cur); }); } catch (e) {}
})();
