// Plotted extension card: shows the listing check on Domain and realestate.com.au listing pages.
// Gets the listing's facts from reader.js, asks the background for the check, and reads the user's budget
// limits from this device's extension storage (copied there by plotted.js when they use Plotted).
(function () {
  if (window.__plottedCard) return;
  window.__plottedCard = true;
  var PLOTTED = 'https://danmoscaritolo.github.io/house-scraper-site/';
  var cur = null, seq = 0, closedKey = null;

  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function money(v) { if (v == null) return '–'; return '$' + (v >= 1e6 ? (v / 1e6).toFixed(v >= 1e7 ? 1 : 2) + 'm' : Math.round(v / 1e3) + 'k'); }
  function pct(v) { return Math.round(Math.abs(v) * 100) + '%'; }
  function mon(day) { return new Date(Date.UTC(2000, 0, 1) + day * 864e5).toLocaleDateString('en-AU', { month: 'short', year: 'numeric', timeZone: 'UTC' }); }
  function title(s) { return String(s || '').toLowerCase().replace(/(^|[\s-])([a-z])/g, function (m, a, b) { return a + b.toUpperCase(); }); }
  function link(r) {
    var q = [];
    ['src', 'url', 'addr', 'unit', 'num', 'street', 'suburb', 'pc', 'state', 'type', 'beds', 'baths', 'cars', 'land', 'floor', 'price', 'mode', 'lat', 'lon', 'id']
      .forEach(function (k) { if (r[k] != null && r[k] !== '') q.push(k + '=' + encodeURIComponent(r[k])); });
    return PLOTTED + '#check?' + q.join('&');
  }
  function getCap() { return new Promise(function (ok) { try { chrome.storage.local.get('cap', function (o) { ok((o && o.cap) || null); }); } catch (e) { ok(null); } }); }

  function box() {
    var c = document.getElementById('plotted-card');
    if (!c) {
      c = document.createElement('div'); c.id = 'plotted-card';
      c.addEventListener('click', onClick);
      document.body.appendChild(c);
    }
    var min = false; try { min = sessionStorage.getItem('plotted-min') === '1'; } catch (e) {}
    c.classList.toggle('pc-min', min);
    return c;
  }
  function head(sum) {
    var min = document.getElementById('plotted-card') && document.getElementById('plotted-card').classList.contains('pc-min');
    return '<div class="pc-h"><span class="pc-wm">plotted<i>.</i></span><span class="pc-sum">' + esc(sum || '') + '</span>' +
      '<button class="pc-ic" data-a="min" title="Minimise">' + (min ? '▴' : '▾') + '</button><button class="pc-ic" data-a="x" title="Close">×</button></div>';
  }

  var WORD = { below: 'Below recent sales', inline: 'In line with recent sales', above: 'Above recent sales' };
  var RWORD = { below: 'Below recent rents', inline: 'In line with recent rents', above: 'Above recent rents' };
  var FIT = { in: 'Within your budget', stretch: 'A stretch for your budget', out: 'Over your budget' };

  function render(r, res, cap, err) {
    var c = box(), facts = [r.beds != null ? r.beds + ' bed' : '', r.baths != null ? r.baths + ' bath' : '', r.cars != null ? r.cars + ' car' : '',
      r.land ? Math.round(r.land) + ' m² land' : '', r.floor ? Math.round(r.floor) + ' m²' : ''].filter(Boolean).join(' · ');
    var html = '', sum = '';
    if (!res && !err) html = '<p class="pc-wait">Checking sales near this home…</p>';
    else if (err) html = '<p class="pc-note">Couldn\'t reach Plotted just now. ' + esc(err).slice(0, 80) + '</p>';
    else if (res.err) html = '<p class="pc-note">' + (r.state && !/nsw/i.test(r.state) ? 'Plotted covers NSW only.' : 'This suburb isn\'t in the NSW sales records.') + '</p>';
    else {
      var noun = res.unit ? 'units' : 'houses', sub = title(res.loc.replace(/ \d{4}$/, ''));
      // verdict
      if (res.mode === 'rent') {
        if (res.rent) {
          var v = res.rent.v, lab = (res.rent.beds != null ? res.rent.beds + '-bed ' : '') + noun + ' in ' + res.pc;
          html += '<p class="pc-vk ' + (res.ver ? 'k-' + res.ver.k : '') + '">' + (res.ver ? RWORD[res.ver.k] : 'Recent rents') + '</p>' +
            '<p class="pc-vs">' + esc(lab) + ' leased for <b>$' + v[1] + '–$' + v[3] + '/wk</b> (median $' + v[2] + ', ' + v[0] + ' leases).' +
            (res.ver ? ' This one is ' + pct(res.ver.diff) + (res.ver.diff >= 0 ? ' above' : ' below') + ' the median.' : '') + '</p>';
          sum = res.ver ? RWORD[res.ver.k] : '';
        } else html += '<p class="pc-note">No recent leases of similar homes in ' + esc(res.pc) + '.</p>';
      } else if (res.st && res.st.n >= 3) {
        var where = res.useBld ? 'units in this ' + (res.multi ? 'complex' : 'building') : (res.unit ? '' : 'similar-sized ') + noun + ' nearby';
        html += '<p class="pc-vk ' + (res.ver ? 'k-' + res.ver.k : '') + '">' + (res.ver ? WORD[res.ver.k] : 'What similar homes sold for') + '</p>' +
          '<p class="pc-vs">' + res.st.n + ' ' + esc(where) + ' sold for <b>' + money(res.st.q25) + '–' + money(res.st.q75) + '</b> in today\'s market (median ' + money(res.st.med) + ').' +
          (res.ver ? ' This price is ' + pct(res.ver.diff) + (res.ver.diff >= 0 ? ' above' : ' below') + ' the median.' : res.price ? '' : ' No price shown to compare.') +
          (res.st.n < 6 ? ' <span class="pc-warn">Few sales, treat with caution.</span>' : '') + '</p>';
        sum = res.ver ? WORD[res.ver.k] : '';
      } else html += '<p class="pc-vk">Too few recent sales nearby to compare</p>';
      // the home's last sale
      if (res.last) {
        var e = res.last.est, ago = (Date.parse(res.asof) - Date.UTC(2000, 0, 1)) / 864e5 - res.last.day;
        html += '<div class="pc-row"><span class="pc-k">Last sold</span><span class="pc-v">' + money(res.last.price) + ' · ' + mon(res.last.day) +
          (e && ago > 180 ? '<br><span class="pc-s">about ' + money(e.v) + ' in today\'s market</span>' : '') + '</span></div>';
      }
      // same building / street
      if (res.near && res.near.length) {
        html += '<div class="pc-near"><p class="pc-k">' + (res.unit ? (res.multi ? 'Sold in this complex' : 'Sold in this building') : 'Sold on this street') +
          ' <span class="pc-s">(' + res.nNear + ' in ' + (res.unit ? '10' : '5') + ' yrs)</span></p>' +
          res.near.slice(0, 4).map(function (n) { return '<div class="pc-nr"><span>' + esc(n.a) + '</span><span>' + money(n.price) + ' <i>' + mon(n.day) + '</i></span></div>'; }).join('') + '</div>';
      }
      // suburb
      if (res.sub && res.sub.med) {
        html += '<div class="pc-row"><span class="pc-k">' + esc(sub) + ' ' + noun + '</span><span class="pc-v">' + money(res.sub.med) + ' median' +
          (res.sub.g1 != null ? '<br><span class="pc-s ' + (res.sub.g1 > 0 ? 'pos' : res.sub.g1 < 0 ? 'neg' : '') + '">' + (res.sub.g1 >= 0 ? '+' : '−') + (Math.abs(res.sub.g1) * 100).toFixed(1) + '% on a year</span>' : '') + '</span></div>';
      }
      // budget
      var pv = res.price && res.price.v;
      if (res.mode === 'rent' ? cap && cap.rent : cap && cap.buy) {
        if (pv) {
          var lim = res.mode === 'rent' ? cap.rent : cap.buy, x = pv / lim, k = x <= 1 ? 'in' : x <= 1.1 ? 'stretch' : 'out';
          html += '<p class="pc-fit f-' + k + '">' + FIT[k] + ' <span class="pc-s">(limit about ' + (res.mode === 'rent' ? '$' + lim + '/wk' : money(lim)) + ')</span></p>';
        }
      } else html += '<p class="pc-s pc-bud">Set <a href="' + PLOTTED + '#budget" target="_blank" rel="noopener">your budget on Plotted</a> to see if listings fit.</p>';
      if (res.rent && res.mode !== 'rent' && pv) html += '<p class="pc-s">Rents nearby: $' + res.rent.v[1] + '–$' + res.rent.v[3] + '/wk, about ' + (res.rent.v[2] * 52 / pv * 100).toFixed(1) + '% gross yield.</p>';
    }
    c.innerHTML = head(sum) + '<div class="pc-b">' + html +
      (facts ? '<p class="pc-facts">' + esc(facts) + '</p>' : '') +
      '<a class="pc-go" target="_blank" rel="noopener" href="' + esc(link(r)) + '">Full check on Plotted</a>' +
      '<p class="pc-fine">Compared with recorded sales and bonds (NSW Government). Not a valuation.</p></div>';
  }

  function onClick(e) {
    var a = e.target.getAttribute && e.target.getAttribute('data-a'), c = document.getElementById('plotted-card');
    if (a === 'x') { closedKey = cur && cur.key; c.remove(); return; }
    if (a === 'min' || (e.target.closest && e.target.closest('.pc-h') && !a)) {
      var m = !c.classList.contains('pc-min'); c.classList.toggle('pc-min', m);
      try { sessionStorage.setItem('plotted-min', m ? '1' : '0'); } catch (err) {}
      var b = c.querySelector('[data-a=min]'); if (b) b.textContent = m ? '▴' : '▾';
    }
  }

  function run(msg) {
    cur = msg; var my = ++seq;
    if (closedKey === msg.key) return;
    render(msg.r, null, null, null);
    Promise.all([
      new Promise(function (ok) { try { chrome.runtime.sendMessage({ type: 'check', L: msg.r }, function (x) { ok(x || { ok: false, err: chrome.runtime.lastError && chrome.runtime.lastError.message }); }); } catch (e) { ok({ ok: false, err: String(e) }); } }),
      getCap()
    ]).then(function (out) {
      if (my !== seq) return;
      var x = out[0];
      render(msg.r, x.ok ? x.res : null, out[1], x.ok ? null : (x.err || 'no reply'));
    });
  }

  window.addEventListener('message', function (e) {
    if (e.source !== window || !e.data || !e.data.__plotted) return;
    if (e.data.__plotted === 'none') { var c = document.getElementById('plotted-card'); if (c) c.remove(); cur = null; return; }
    if (e.data.__plotted === 'listing') {
      // only re-run when the facts that matter change
      var k = JSON.stringify([e.data.key, e.data.r.suburb, e.data.r.street, e.data.r.num, e.data.r.unit, e.data.r.price, e.data.r.beds, e.data.r.land, e.data.r.lat]);
      if (cur && cur._k === k) return;
      e.data._k = k; run(e.data);
    }
  });
  try { chrome.storage.onChanged.addListener(function (ch) { if (ch.cap && cur) run(cur); }); } catch (e) {}
})();
